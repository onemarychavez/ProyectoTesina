<?php
namespace App\Model;

use CodeIgniter\Model;

class CustomerModel extends Model
{

    protected $table = "customer";

    protected $primaryKey = "id";

    protected $useAutoIncrement = true;

    protected $returnType = "array";

    protected $allowedFields = ['first_name','last_name','email','gender'];

    protected $useTimestamps = false;

    protected $validationRules = [];

    protected $validationMessages = false;

    protected $skipValidation = false;
}