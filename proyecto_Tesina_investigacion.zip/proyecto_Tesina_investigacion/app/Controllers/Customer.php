<?php
namespace App\Controllers;

use App\Model\CustomerModel;

class Customer extends BaseController
{
    public function index()
    {
        $model = model(CustomerModel::class);
        $customers = $model->findAll();
        echo "Practica";
    }
}